Handshake package
=================

Structure:
- rtl/handshake_slave.sv
- tb_uvm/
- formal/
- cpp/

Run:
- Compile and run tb_top_hs (UVM test hs_test)
- Formal: jasper -f formal/jg_run.tcl
