# SYSTEMVERILOG Design Problems

## 1. 2-Port Fair Arbiter
- File: `rr_arbiter2`
- Description: Round-robin logic

## 2. Simple FIFO
- File: `fifo_simple`
- Description: Depth=4 push/pop

## 3. 4-State FSM
- File: `fsm4`
- Description: IDLE, READ, WRITE, DONE

## 4. Handshake Protocol
- File: `handshake`
- Description: req/ack with assertions

## 5. Priority Arbiter
- File: `arb_priority`
- Description: Fixed priority 4 ports

## 6. Round-Robin Arbiter N ports
- File: `arb_round_robin`
- Description: Fair arbitration

## 7. Dual-Port RAM
- File: `dual_port_ram`
- Description: Separate read/write ports

## 8. Parameterized FIFO
- File: `fifo_param`
- Description: Almost full/empty flags

## 9. AXI-lite Slave Stub
- File: `axi_lite_stub`
- Description: Respond to read/write

## 10. Cache Line Replacement Policy
- File: `cache_lru`
- Description: LRU logic

