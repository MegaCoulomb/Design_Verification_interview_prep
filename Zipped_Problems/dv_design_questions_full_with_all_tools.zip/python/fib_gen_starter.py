# fib_gen_starter.py
def fib():
    # TODO: generator
    pass

if __name__=='__main__':
    f = fib()
    for _ in range(10): print(next(f))
