# prod_cons_starter.py
import threading, time
# Implement producer-consumer with queue
