# fifo_queue_starter.py
class FIFOQueue:
    def __init__(self):
        self.queue = []
    def enqueue(self, item):
        pass
    def dequeue(self):
        pass
    def peek(self):
        pass
