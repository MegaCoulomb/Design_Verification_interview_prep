# merge_sorted_starter.py
def merge(a,b):
    # TODO
    pass
