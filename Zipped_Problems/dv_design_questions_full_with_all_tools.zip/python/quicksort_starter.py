# quicksort_starter.py
def quicksort(a): pass
