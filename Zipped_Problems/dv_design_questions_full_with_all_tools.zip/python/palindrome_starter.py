# palindrome_starter.py
def is_palindrome(s): 
    # TODO
    pass

if __name__=='__main__': print(is_palindrome('racecar'))
