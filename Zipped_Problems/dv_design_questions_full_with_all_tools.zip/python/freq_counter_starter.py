# freq_counter_starter.py
def word_freq(text):
    # TODO
    pass
