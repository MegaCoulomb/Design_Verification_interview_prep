from merge_sorted_solution import merge
def test_merge():
    assert merge([1,3,5],[2,4,6]) == [1,2,3,4,5,6]
