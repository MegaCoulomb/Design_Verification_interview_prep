# matrix_rot_starter.py
def rotate90(m):
    # TODO in-place rotate NxN matrix
    pass
