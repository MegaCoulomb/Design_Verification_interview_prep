# PYTHON Design Problems

## 1. FIFO Queue Class
- File: `fifo_queue`
- Description: Enqueue/dequeue/peek

## 2. Palindrome Checker
- File: `palindrome`
- Description: String same forwards/backwards

## 3. Fibonacci Generator
- File: `fib_gen`
- Description: Iterator with yield

## 4. Dictionary Frequency Counter
- File: `freq_counter`
- Description: Word counts

## 5. Merge Two Sorted Lists
- File: `merge_sorted`
- Description: Sorted output

## 6. LRU Cache
- File: `lru_cache`
- Description: Use OrderedDict or custom

## 7. Producer-Consumer
- File: `prod_cons`
- Description: Threading + Queue

## 8. Matrix Rotation 90°
- File: `matrix_rot`
- Description: Rotate NxN matrix

## 9. QuickSort
- File: `quicksort`
- Description: Recursive divide & conquer

## 10. Async Web Scraper
- File: `async_scraper`
- Description: aiohttp multiple URLs

