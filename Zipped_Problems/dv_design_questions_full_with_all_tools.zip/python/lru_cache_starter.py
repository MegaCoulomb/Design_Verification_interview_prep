# lru_cache_starter.py
from collections import OrderedDict
class LRUCache:
    def __init__(self, capacity): pass
    def get(self, key): pass
    def put(self, key, value): pass
