# async_scraper_starter.py
import asyncio
# use aiohttp to fetch multiple urls concurrently
