/* stack_array_starter.c */
#include <stdio.h>
#define MAX 10
typedef struct { int a[MAX]; int top; } stack;
// implement push pop peek
