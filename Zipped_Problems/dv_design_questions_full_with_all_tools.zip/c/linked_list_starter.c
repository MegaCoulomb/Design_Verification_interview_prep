/* linked_list_starter.c */
#include <stdio.h>
typedef struct node { int val; struct node *next; } node;
// Implement insert_front, delete_value, print_list
