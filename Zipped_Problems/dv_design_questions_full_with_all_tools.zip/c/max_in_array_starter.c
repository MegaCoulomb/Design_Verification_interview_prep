/* max_in_array_starter.c */
#include <stdio.h>

int find_max(int *arr, int n) {
    // TODO
}

int main() {
    int a[] = {3, 1, 4, 1, 5, 9};
    printf("%d\n", find_max(a, 6));
    return 0;
}
