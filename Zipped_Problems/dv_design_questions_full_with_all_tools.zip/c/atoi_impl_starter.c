/* atoi_starter.c */
#include <stdio.h>
#include <ctype.h>
int my_atoi(const char *s) { /* TODO */ }
int main(){ printf("%d\n", my_atoi(" -123 ")); return 0; }
