/* bsearch_starter.c */
#include <stdio.h>
int bsearch_idx(int *a, int n, int key) { /* TODO */ }
int main(){ int a[]={1,3,5,7,9}; printf("%d\n", bsearch_idx(a,5,7)); return 0; }
