# C Design Problems

## 1. Reverse a String
- File: `reverse_string`
- Description: Swap chars in place

## 2. Find Max in Array
- File: `max_in_array`
- Description: Linear scan O(n)

## 3. Matrix Multiplication
- File: `matrix_mul`
- Description: Nested loops NxN

## 4. Count Bits
- File: `bit_count`
- Description: Brian Kernighan’s algorithm

## 5. Linked List
- File: `linked_list`
- Description: Insert/delete nodes

## 6. Stack with Array
- File: `stack_array`
- Description: Push/pop/peek

## 7. Queue with Two Stacks
- File: `queue_stacks`
- Description: Enqueue/dequeue

## 8. Implement atoi()
- File: `atoi_impl`
- Description: String to integer

## 9. Binary Search
- File: `binary_search`
- Description: Iterative/recursive

## 10. Memory Copy with Overlap
- File: `memmove_impl`
- Description: Implement memmove

