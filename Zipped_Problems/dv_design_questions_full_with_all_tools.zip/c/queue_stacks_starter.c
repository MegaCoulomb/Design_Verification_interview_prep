/* queue_stacks_starter.c */
#include <stdio.h>
// Implement queue using two stacks (arrays)
