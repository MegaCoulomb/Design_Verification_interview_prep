/* bit_count_starter.c */
#include <stdio.h>
unsigned int popcount(unsigned int x) {
    // TODO: implement (Brian Kernighan)
}
int main() { printf("%u\n", popcount(0b101101)); return 0; }
