/* reverse_string_starter.c */
#include <stdio.h>
#include <string.h>

void reverse(char *str) {
    // TODO: implement
}

int main() {
    char s[] = "HELLO";
    reverse(s);
    printf("%s\n", s);
    return 0;
}
