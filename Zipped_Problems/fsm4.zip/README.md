FSM4 package
============

Structure:
- rtl/fsm4.sv
- tb_uvm/
- formal/
- cpp/

Run:
- Compile and run top tb_top_fsm (UVM test fsm_test)
- Formal: jasper -f formal/jg_run.tcl
