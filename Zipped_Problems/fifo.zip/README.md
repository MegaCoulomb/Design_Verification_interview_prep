FIFO package
============

Structure:
- rtl/fifo_sync.sv
- tb_uvm/
- formal/
- cpp/

Build & Run:
- Compile with your simulator (ensure UVM library included)
- Run top module tb_top_fifo which runs UVM test fifo_test
- JasperGold: use formal/jg_run.tcl
